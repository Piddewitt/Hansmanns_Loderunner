The level disks in here are converted from their MSX binaries.

Many levels do not have a legal solution as the MSX enemies heavily misbehave.
If you encounter one of these try to modify it for solution. Sometimes it helps
if the game speed is reduced, especaially for those levels which require a move
on some enemmy heads.

All level disks have a set for the DARTS loder runner on board. With WinVice these
sets have to be loaded with flag 'True drive emulation' activated.

hg

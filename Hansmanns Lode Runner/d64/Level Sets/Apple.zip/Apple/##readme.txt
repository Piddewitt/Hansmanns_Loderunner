The level disks in here are converted from Ian Humphreys Apple Lode Runner remake
which can be found at http://www.spoonbillsoftware.com.au/loderunner.htm

Most of the levels should be playable with the c64 version except some because
the apple enemies slightly misbehave.

It is probably hard hard to decide if you have encountered one of these. If you
are sure correct it then or simply ignore it as there will be enough levels left
over which will have a legal solution.

All level disks have a set for the DARTS loder runner on board. With WinVice these
sets have to be loaded with flag 'True drive emulation' activated.

hg
